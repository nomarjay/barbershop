import { useState } from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  const [open, setOpen] = useState(false);

  return (
    <nav className="navbar navbar-expand-lg shadow-sm fixed-top py-3">
      <div className="container">

        {/* Brand */}
        <Link className="navbar-brand fw-bold" to="/">
          <i className="fa-solid fa-scissors"></i> Style Cutz
        </Link>

        {/* React Hamburger Toggle */}
        <button
          className="navbar-toggler"
          type="button"
          onClick={() => setOpen(!open)}
        >
          <span className="navbar-toggler-icon"></span>
        </button>

        {/* Links */}
        <div className={`collapse navbar-collapse ${open ? "show" : ""}`} id="navMenu">
          <ul className="navbar-nav ms-auto fw-semibold">
            <li className="nav-item">
              <Link
                className="nav-link"
                to="/"
                onClick={() => setOpen(false)}
              >
                Home
              </Link>
            </li>

            <li className="nav-item">
              <Link
                className="nav-link"
                to="/services"
                onClick={() => setOpen(false)}
              >
                Services
              </Link>
            </li>

            <li className="nav-item">
              <Link
                className="nav-link"
                to="/about"
                onClick={() => setOpen(false)}
              >
                About
              </Link>
            </li>
          </ul>

          <Link
            to="/contact"
            className="btn btn-dark ms-3"
            onClick={() => setOpen(false)}
          >
            Book Now
          </Link>
        </div>
      </div>
    </nav>
  );
};

export default Navbar;
